package com.connect.fragment;

/**
 * Created by win7 on 14-10-2016.
 */

public interface MessagePasserInterface {

    public void onMessage(String message);
}
